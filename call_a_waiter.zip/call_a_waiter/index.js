
const mqtt = require('mqtt');

// MQTT broker URL and port
const mqttBrokerUrl = 'mqtt://10.63.3.68:1883';
//192.168.43.240


// Create a client instance
const mqttClient = mqtt.connect(mqttBrokerUrl);

// When the client is connected, log a message
mqttClient.on('connect', () => {
  console.log('Connected to MQTT broker!');

  mqttClient.subscribe('callawaiter');
});

// When the client receives a message, log the message payload
mqttClient.on('message', (topic, message) => {
  console.log(`Received message: ${message.toString()} on topic ${topic}`);
});



// Subscribe to a topic
mqttClient.subscribe('test/topic');

// Publish a message to a topic
mqttClient.publish('test/topic2', 'Hello, MQTT!');

const express = require('express');
const app = express();
const ejs = require('ejs');

app.set('view engine', 'ejs');

app.get('/', function(req, res) {
  res.render('index', { title: 'My Website', message: 'Welcome to my website!' });
});

app.use(express.json())

app.post('/publish', function(req, res) {
  console.log(req.body)
  mqttClient.publish('test/topic', 'Hello, MQTT!');
  res.send("hello");
});

app.listen(3000, function() {
  console.log('Server started on port 3000');
});